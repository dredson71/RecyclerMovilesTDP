package com.example.reciclemosdemo.Adicionales;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class dbHelper extends SQLiteOpenHelper {
    public dbHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table usuarios(codigo integer primary key autoincrement, nombres text, apellidos text, dni text unique, " +
                "nacimiento text, condominio integer, direccion text, email text unique, password text, salt text)");
        db.execSQL("create table departamentos(codigo integer primary key autoincrement, nombre text)");
        db.execSQL("insert into departamentos (nombre) values ('Lima Metropolitana'),('Callao')");
        db.execSQL("create table condominios(codigo integer primary key autoincrement, nombre text, distrito integer)");
        db.execSQL("insert into condominios (nombre, distrito) values ('Las Palomas', 1),('Las Focas', 1),('Los Osos', 1),('Las Cabras', 12),('Los Loros', 12),('Los Orcos', 12)," +
                "('Las Plantas', 22),('Las Rosas', 22),('Los Pumas', 22),('Las Abejas', 26),('Las Jirafas', 26),('Los Tigres', 26),('Las Llamas', 35),('Las Alpacas', 35),('Los Leones', 35)");
        db.execSQL("create table distritos(codigo integer primary key autoincrement, nombre text, departamento integer)");
        db.execSQL("insert into distritos (nombre, departamento) values ('Callao', 2),('Bellavista', 2),('Carmen de La Legua', 2),('La Perla', 2),('La Punta', 2)," +
                "('Mi Perú', 2),('Ventanilla', 2),('Lima', 1),('Ancón', 1),('Ate', 1),('Barranco', 1),('Breña', 1),('Carabayllo', 1),('Chorrillos', 1)," +
                "('Comas', 1),('El Agustino', 1),('Independencia', 1),('Jesús María', 1),('La Molina', 1),('La Victoria', 1),('Lince', 1),('Los Olivos', 1)," +
                "('Lurigancho', 1),('Lurín', 1),('Magdalena del Mar', 1),('Miraflores', 1),('Pachacámac', 1),('Pucusana', 1),('Pueblo Libre', 1),('Puente Piedra', 1)," +
                "('Punta Hermosa', 1),('Punta Negra', 1),('Rímac', 1),('San Bartolo', 1),('San Borja', 1),('San Isidro', 1),('San Juan de Lurigancho', 1)," +
                "('San Juan de Miraflores', 1),('San Luis', 1),('San Martín de Porres', 1),('San Miguel', 1),('Santa Anita', 1),('Santa María del Mar', 1)," +
                "('Santa Rosa', 1),('Santiago de Surco', 1),('Surquillo', 1),('Villa El Salvador', 1),('Villa María del Triunfo', 1)");
        db.execSQL("create table registros(codigo integer primary key autoincrement, barcode text unique, nombre text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
