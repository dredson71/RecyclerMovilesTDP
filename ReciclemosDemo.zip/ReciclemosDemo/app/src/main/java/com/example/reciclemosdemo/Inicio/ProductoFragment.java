package com.example.reciclemosdemo.Inicio;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import com.example.reciclemosdemo.Adicionales.AnyOrientationCaptureActivity;
import com.example.reciclemosdemo.Entities.Bolsa;
import com.example.reciclemosdemo.Entities.JsonPlaceHolderApi;
import com.example.reciclemosdemo.Entities.Probolsa;
import com.example.reciclemosdemo.Entities.Producto;
import com.example.reciclemosdemo.Entities.Usuario;
import com.example.reciclemosdemo.R;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ProductoFragment extends Fragment {

    public ProductoFragment() {
        // Required empty public constructor
    }

    Button btnEscanear, btnAgregar;
    TextView txtTipo, txtNombre, txtContenido, txtPeso, txtPuntos;
    NumberPicker numberPicker;
    private Retrofit retrofit;
    private double numpeso;
    private Producto pro;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_producto, container, false);

        txtTipo = v.findViewById(R.id.txtTipo);
        txtNombre = v.findViewById(R.id.txtNombre);
        txtContenido = v.findViewById(R.id.txtContenido);
        txtPeso = v.findViewById(R.id.txtPeso);
        txtPuntos = v.findViewById(R.id.txtPuntos);
        btnEscanear = v.findViewById(R.id.btnEscanear);
        btnAgregar = v.findViewById(R.id.btnAgregar);
        numberPicker = v.findViewById(R.id.numberPicker);

        retrofit = new Retrofit.Builder()
                .baseUrl("https://recyclerapiresttdp.herokuapp.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        numberPicker.setOnValueChangedListener(onValueChangeListener);

        btnEscanear.setOnClickListener(mOnClickListener);
        btnAgregar.setOnClickListener(mOnClickListener);

        return v;
    }


    private NumberPicker.OnValueChangeListener onValueChangeListener = new NumberPicker.OnValueChangeListener() {

        @Override
        public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
            if(txtPeso.getText().toString().compareTo("Peso") != 0) {
                txtPuntos.setText((numberPicker.getValue() * 10) + " pts.");
                if((numpeso * numberPicker.getValue()) < 500.0)
                    txtPeso.setText((numpeso * numberPicker.getValue()) + " gr");
                else{
                    txtPeso.setText(((numpeso * numberPicker.getValue())/1000.0) + " kg");
                }
            }
        }
    };

    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if(result != null)
            if (result.getContents() != null) {

                //AQUI COLOCO EL CODIGO EN LA CAJA DE TEXTO, DICHO CODIGO PUEDE SER USADO EN TODOS LOS METODOS CRUD

                GetProducto(result.getContents(), new EntityCallBack<Producto>() {
                    @Override
                    public void onSuccess(@NonNull Producto value) {
                        pro = value;
                    }

                    @Override
                    public void onError(@NonNull Throwable throwable) {

                    }
                });
            } else {
                Toast.makeText(getActivity().getApplicationContext(), "Error al escanear", Toast.LENGTH_LONG).show();
            }
    }

    private View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btnEscanear:
                    IntentIntegrator integrator = new IntentIntegrator(getActivity()).forSupportFragment(ProductoFragment.this);
                    integrator.setCaptureActivity(AnyOrientationCaptureActivity.class);
                    integrator.setOrientationLocked(false);
                    integrator.initiateScan();
                    break;
                case R.id.btnAgregar:
                    AddProBolsa();
                    break;
            }
        }
    };

    //INTERFACE ENTITY
    public interface EntityCallBack<T> {

        void onSuccess(@NonNull T value);

        void onError(@NonNull Throwable throwable);
    }

    private void AddProBolsa(){
        if(txtNombre.getText().toString().compareTo("Nombre Producto") != 0){

            Bolsa bolsa = new Bolsa();
            bolsa.setCodigo(3);

            Probolsa nuevo = new Probolsa();
            nuevo.setBolsa(bolsa);
            nuevo.setPeso((numpeso * numberPicker.getValue()));
            nuevo.setProducto(pro);
            nuevo.setPuntuacion((numberPicker.getValue() * 10));

            JsonPlaceHolderApi jsonPlaceHolderApi=retrofit.create(JsonPlaceHolderApi.class);
            Call<Probolsa> call=jsonPlaceHolderApi.addProBolsa(nuevo);
            call.enqueue(new Callback<Probolsa>() {
                @Override
                public void onResponse(Call<Probolsa> call, Response<Probolsa> response) {
                    if(response.isSuccessful()){
                        Toast.makeText(getActivity().getApplicationContext(), "Producto agregado a la bolsa 3", Toast.LENGTH_LONG).show();
                        Log.e("TAG","onResponse:" + response.toString());
                    }
                }

                @Override
                public void onFailure(Call<Probolsa> call, Throwable t) {
                    Log.e("TAG","onFailure:" + t.getMessage());
                }
            });
        }
        else{
            Toast.makeText(getActivity().getApplicationContext(), "Escanee un producto", Toast.LENGTH_LONG).show();
        }
    }

    private void GetProducto(String barCode, @Nullable final EntityCallBack entityCallBack){
        JsonPlaceHolderApi jsonPlaceHolderApi=retrofit.create(JsonPlaceHolderApi.class);
        Call<Producto> call=jsonPlaceHolderApi.getProductoByBarCode("producto/barcode/"+barCode);
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                try {
                    if(response.isSuccessful()) {
                        entityCallBack.onSuccess(response.body());
                        Producto productos = response.body();
                        String nombre=productos.getNombre();
                        Double peso=productos.getPeso();
                        Double contenido=productos.getContenido();
                        String categoria_nombre = productos.getCategoria().getNombre();
                        String abreviatura = productos.getTipo_Contenido().getAbreviatura();
                        txtTipo.setText(categoria_nombre);
                        txtNombre.setText(nombre);
                        txtPeso.setText(peso.toString() + " gr");
                        numpeso = peso;
                        txtContenido.setText(contenido.toString() + " " + abreviatura);
                        numberPicker.setMaxValue(50);
                        numberPicker.setMinValue(1);
                        numberPicker.setValue(1);
                        txtPuntos.setText((numberPicker.getValue() * 10) + " pts.");
                        if((numpeso * numberPicker.getValue()) < 500.0)
                            txtPeso.setText((numpeso * numberPicker.getValue()) + " gr");
                        else{
                            txtPeso.setText(((numpeso * numberPicker.getValue())/1000.0) + " kg");
                        }
                    }else{
                        Toast.makeText(getActivity().getApplicationContext(), "Error al escanear", Toast.LENGTH_LONG).show();
                        Log.e("TAG","onResponse:" + response.toString());
                    }
                }catch(Exception e){
                    txtTipo.setText("Tipo");
                    txtNombre.setText("Nombre Producto");
                    txtPeso.setText("Peso");
                    txtContenido.setText("Contenido");
                    numberPicker.setMinValue(0);
                    numberPicker.setMaxValue(0);
                    txtPuntos.setText("Puntos");
                    Toast.makeText(getActivity().getApplicationContext(), "No existe producto", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                Log.e("TAG","onFailure:" + t.getMessage());
            }
        });
    }

}


