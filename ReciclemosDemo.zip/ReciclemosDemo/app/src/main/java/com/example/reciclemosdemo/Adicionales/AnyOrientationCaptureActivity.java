package com.example.reciclemosdemo.Adicionales;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.reciclemosdemo.R;
import com.journeyapps.barcodescanner.CaptureActivity;

public class AnyOrientationCaptureActivity extends CaptureActivity {

}
