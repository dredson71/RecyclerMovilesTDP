package com.example.reciclemosdemo.Grafico;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import androidx.recyclerview.widget.RecyclerView;

import com.example.reciclemosdemo.Entities.Bolsa;
import com.example.reciclemosdemo.Entities.Probolsa;
import com.example.reciclemosdemo.R;

public class ListaBolsaAdapter extends RecyclerView.Adapter<ListaBolsaAdapter.ViewHolder> {

    private ArrayList<Bolsa> dataset;
    private Context context;
    private OnNoteListener canonNoteListener;
    private int countBolsas;

    public ListaBolsaAdapter(Context context)
    {
        this.context=context;
        dataset= new ArrayList<>();
        countBolsas=0;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent , int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bolsalist,parent,false);

        return new ViewHolder(view,canonNoteListener);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder,int position){

        countBolsas++;
        Bolsa c = dataset.get(position);
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        String recojoFecha = formatter.format(c.getRecojoFecha());
        String creadoFecha = formatter.format(c.getCreadoFecha());
        holder.txt_Bolsa.setText("Bolsa "+Integer.toString(countBolsas));
        holder.txt_RecojoFecha.setText("Creada : "+recojoFecha);
        holder.txt_CreadoFecha.setText("Recogida : "+creadoFecha);

    }

    @Override
    public int getItemCount(){
        return dataset.size();
    }


    public void adicionarListaCancion(ArrayList<Bolsa> listaCancion,OnNoteListener canonNoteListener){
        dataset.addAll(listaCancion);
        notifyDataSetChanged();
        this.canonNoteListener=canonNoteListener;
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView txt_Bolsa;
        private TextView txt_RecojoFecha;
        private TextView txt_CreadoFecha;
        OnNoteListener onNoteListener;

        public ViewHolder(View itemView ,OnNoteListener onNoteListener ){
            super(itemView);
            txt_Bolsa=(TextView) itemView.findViewById(R.id.txtBolsa);
            txt_CreadoFecha=(TextView) itemView.findViewById(R.id.txtCreadoFecha);
            txt_RecojoFecha=(TextView) itemView.findViewById(R.id.txtRecoojoFecha);
            this.onNoteListener=onNoteListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onNoteListener.oneNoteClick(getAdapterPosition());
        }
    }

    public interface OnNoteListener{
        void oneNoteClick(int position);
    }
}