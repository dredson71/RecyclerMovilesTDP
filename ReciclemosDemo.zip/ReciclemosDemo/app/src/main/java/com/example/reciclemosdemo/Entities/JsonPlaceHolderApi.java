package com.example.reciclemosdemo.Entities;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface JsonPlaceHolderApi {
    @GET
    Call<Producto> getProductoById(@Url String url);

    @GET
    Call<List<Bolsa>> getBolsasByUsuario(@Url String url);

    @GET
    Call<List<Probolsa>> getProductoByIdBolsa(@Url String url);

    @GET
    Call<List<Probolsa>> getBolsasByDate(@Url String url);

    @GET
    Call<Producto> getProductoByBarCode(@Url String url);

    @GET
    Call<List<Departamento>> getAllDepartamento(@Url String url);

    @GET
    Call<List<Distrito>> getDistritoByDepartamento(@Url String url);

    @GET
    Call<List<Condominio>> getCondominioByDistrito(@Url String url);

    @GET
    Call<Sexo> getSexoById(@Url String url);

    @GET
    Call<Tipo_Usuario> getTipoUsuarioById(@Url String url);

    @GET
    Call<Usuario> getUsuarioByEmail(@Url String url);

    @GET
    Call<Usuario> getUsuarioByDNI(@Url String url);

    @POST("usuario")
    Call<Usuario> createUsuario(@Body Usuario usuario);

    @POST("probolsa")
    Call<Probolsa> addProBolsa(@Body Probolsa probolsa);
}
